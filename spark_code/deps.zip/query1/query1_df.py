from pyspark.sql import functions as F
from deps.utils import *

def process_query1_df(df, _spark):
    """Questa funzione fa SOLO i calcoli e restituisce il Dataframe finale"""
    df_filtered = df.filter(F.col(CARRIER).isin("AA", "DL"))

    result = df_filtered.groupBy(MONTH, CARRIER).agg(
        F.round(F.mean(F.when(F.col(CANCELLED) == 0, F.col(DEP_DELAY))), 2).alias("dep_delay_mean"),
        F.min(F.when(F.col(CANCELLED) == 0, F.col(DEP_DELAY))).alias("dep_delay_min"),
        F.max(F.when(F.col(CANCELLED) == 0, F.col(DEP_DELAY))).alias("dep_delay_max"),
        F.round((F.sum(CANCELLED) / F.count("*")) * 100, 2).alias("cancellation_rate")
    ).orderBy(MONTH, CARRIER)

    return result.withColumnRenamed("MONTH", "month").withColumnRenamed("OP_UNIQUE_CARRIER", "op_unique_carrier")


def run(spark, dataset_path: str, FILE_FORMAT: str, TIMED: bool) -> float:
    """Questa è l'unica riga che serve per far girare tutto!"""
    return run_query_pipeline(spark, dataset_path, FILE_FORMAT, TIMED, query_num=1, api_name="df", core_logic_func=process_query1_df)